import { integer, sqliteTable, text, index } from "drizzle-orm/sqlite-core";
export const runs = sqliteTable("runs", {
  id: text("id").primaryKey(),
  questionIds: text("question_ids").notNull(),
  position: integer("position").notNull().default(0),
  correct: integer("correct").notNull().default(0),
  score: integer("score").notNull().default(0),
  startedAt: integer("started_at").notNull(),
  questionStartedAt: integer("question_started_at").notNull(),
  finishedAt: integer("finished_at"),
  nickname: text("nickname"),
}, (table) => [index("idx_runs_score_finished").on(table.score, table.finishedAt)]);
