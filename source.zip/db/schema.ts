import { integer, sqliteTable, text, index } from "drizzle-orm/sqlite-core";
export const runs = sqliteTable("runs", {
  id: text("id").primaryKey(),
  questionIds: text("question_ids").notNull(),
  position: integer("position").notNull().default(0),
  correct: integer("correct").notNull().default(0),
  score: integer("score").notNull().default(0),
  startedAt: integer("started_at").notNull(),
  questionStartedAt: integer("question_started_at").notNull(),
  elapsedMs: integer("elapsed_ms").notNull().default(0),
  activeSince: integer("active_since"),
  finishedAt: integer("finished_at"),
  nickname: text("nickname"),
}, (table) => [index("idx_runs_score_finished").on(table.score, table.finishedAt)]);

export const dailyRuns = sqliteTable("daily_runs", {
  id: text("id").primaryKey(),
  testKey: text("test_key").notNull(),
  questionIds: text("question_ids").notNull(),
  choicesJson: text("choices_json").notNull().default("[]"),
  position: integer("position").notNull().default(0),
  correct: integer("correct").notNull().default(0),
  startedAt: integer("started_at").notNull(),
  elapsedMs: integer("elapsed_ms").notNull().default(0),
  activeSince: integer("active_since"),
  finishedAt: integer("finished_at"),
  nickname: text("nickname"),
}, (table) => [index("idx_daily_runs_board").on(table.testKey, table.correct, table.finishedAt)]);
