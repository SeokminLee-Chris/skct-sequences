import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const bank = JSON.parse(readFileSync(join(root, "lib/bank.json")));
const meta = JSON.parse(readFileSync(join(root, "lib/bank-meta.json")));
const diff = (a) => a.slice(1).map((v, i) => v - a[i]);
const same = (a) => a.every((v) => v === a[0]);
const arithmetic = (a) => same(diff(a));
const primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59];
const consecutive = (a, candidates) => candidates.some((_, i) => a.every((v, j) => v === candidates[i + j]));
const fibCorrection = (a) => a.slice(2).map((v, i) => v - a[i] - a[i + 1]);
const signed = (a) => a.every((v, i) => (i % 2 ? v < 0 : v > 0));
const group = (a, op) => a.every((v, i) => i % 3 !== 2 || v === op(a[i - 2], a[i - 1]));
const integer = (a) => a.every(Number.isInteger);

function matches(q) {
  const raw = [...q.terms, q.answer];
  const n = raw.map(Number);
  const parts = raw.map((x) => x.split("/").map(Number));
  const length = raw.length;
  switch (q.family) {
    case "증가하는 계차": return arithmetic(diff(n)) && diff(diff(n))[0] > 0;
    case "두 배씩 커지는 계차": return diff(n).every((v, i, a) => i === 0 || v === a[i - 1] * 2);
    case "피보나치와 고정 보정": return same(fibCorrection(n)) && fibCorrection(n)[0] > 0;
    case "피보나치와 교대 보정": { const c = fibCorrection(n); return c.every((v, i) => v === c[i % 2]) && c[0] > 0 && c[1] < 0; }
    case "홀짝 등차·등비": { const odd = n.filter((_, i) => i % 2 === 0), even = n.filter((_, i) => i % 2); return arithmetic(odd) && even.every((v, i) => i === 0 || v === even[i - 1] * (even[1] / even[0])); }
    case "홀짝 독립 계차": return [0, 1].every((p) => arithmetic(diff(n.filter((_, i) => i % 2 === p))));
    case "곱셈·증가하는 덧셈": return [2, 3].some((m) => [1, 2, 3, 4, 5].some((c) => n.slice(1).every((v, i) => i % 2 || v === n[i] * m - c) && arithmetic(diff(n).filter((_, i) => i % 2))));
    case "증감 교대": return arithmetic(diff(n).filter((_, i) => i % 2 === 0)) && arithmetic(diff(n).filter((_, i) => i % 2 === 1)) && diff(n).every((v, i) => i % 2 ? v < 0 : v > 0);
    case "통분 후 분자 계차": return [12, 18, 24, 30, 36, 60].some((d) => parts.every(([num, den]) => d % den === 0) && arithmetic(diff(parts.map(([num, den]) => num * d / den))));
    case "통분 후 분자 재귀": return [24, 30, 36, 60].some((d) => parts.every(([num, den]) => d % den === 0) && same(fibCorrection(parts.map(([num, den]) => num * d / den))));
    case "분자 계차·분모 등차": return arithmetic(diff(parts.map((p) => p[0]))) && arithmetic(parts.map((p) => p[1]));
    case "분자 피보나치·분모 등차": return same(fibCorrection(parts.map((p) => p[0]))) && arithmetic(parts.map((p) => p[1]));
    case "소수점 계차": return arithmetic(diff(raw.map((x) => Math.round(Number(x) * 10))));
    case "정수부·소수부 분리": return arithmetic(raw.map((x) => Math.trunc(Number(x)))) && [2, 3, 4].some((step) => raw.map((x) => Number(x.split(".")[1])).every((v, i, a) => i === 0 || v === (a[i - 1] + step) % 10));
    case "세 수 묶음 합": return length === 9 && group(n, (a, b) => a + b);
    case "세 수 묶음 곱": return length === 9 && [1, 2, 3, 4, 5].some((c) => group(n, (a, b) => a * b + c));
    case "제곱수·교대 보정": return [...Array(6)].some((_, k) => { const s = k + 2; return n.slice(0, 3).every((v, i) => Number.isInteger(v - (s + i) ** 2)) && n.every((v, i) => v - (s + i) ** 2 === n[i % 2] - (s + i % 2) ** 2); });
    case "연속 제곱의 합": return [...Array(17)].some((_, k) => { const s = k + 2, c = n[0] - s ** 2 - (s + 1) ** 2; return c >= 2 && c <= 16 && n.every((v, i) => v === (s + i) ** 2 + (s + i + 1) ** 2 + c); });
    case "소수만큼 증가": return consecutive(diff(n), primes);
    case "소수와 배수의 결합": return [0, 1, 2, 3].some((start) => [2, 3, 4, 5].some((factor) => [1, 2].some((step) => [1, 2, 3, 4, 5].some((c) => n.every((v, i) => v === primes[start + i] * (factor + i * step) + c)))));
    case "두 배와 증가하는 보정": return arithmetic(n.slice(1).map((v, i) => v - 2 * n[i]));
    case "두 번씩 바뀌는 곱": return [1, 2, 3, 4, 5, 6, 7].some((c) => n.slice(1).every((v, i) => v === n[i] * (2 + Math.floor(i / 2)) - c));
    case "부호 교대 피보나치": return signed(n) && same(fibCorrection(n.map(Math.abs)));
    case "부호 교대 제곱": return signed(n) && [...Array(17)].some((_, k) => { const s = k + 2, c = Math.abs(n[0]) - s ** 2; return c >= 1 && c <= 15 && n.every((v, i) => Math.abs(v) === (s + i) ** 2 + c); });
    default: return false;
  }
}

assert.equal(meta.total, bank.length);
assert.equal(meta.familyCount, 24);
assert.equal(meta.groupCount, 12);
assert.deepEqual(meta.termLengths, [6, 7, 8, 9, 10]);
const ids = new Set();
const sequences = new Set();
for (const q of bank) {
  assert(!ids.has(q.id), `duplicate ID ${q.id}`);
  ids.add(q.id);
  const key = q.terms.join("|");
  assert(!sequences.has(key), `duplicate sequence ${q.id}`);
  sequences.add(key);
  assert(q.terms.length >= 6 && q.terms.length <= 10, q.id);
  assert.equal(q.options.length, 5, q.id);
  assert.equal(new Set(q.options).size, 5, q.id);
  assert(q.options.includes(q.answer), q.id);
  assert(!q.terms.includes(q.answer), q.id);
  assert(q.explanation.includes(q.answer), q.id);
  assert(matches(q), `${q.id}: ${q.family}: ${[...q.terms, q.answer].join(", ")}`);
}
console.log(`Verified ${bank.length} questions across ${meta.familyCount} families.`);
