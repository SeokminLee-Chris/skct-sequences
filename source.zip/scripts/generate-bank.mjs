import { writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

// Original practice questions. Public test reports inform the pattern families;
// no reported or commercial question text is copied into this bank.
const root = join(dirname(fileURLToPath(import.meta.url)), "..");
let state = 0x5c7c2026;
const rand = () => ((state = (Math.imul(state, 1664525) + 1013904223) >>> 0) / 4294967296);
const int = (a, b) => a + Math.floor(rand() * (b - a + 1));
const pick = (items) => items[int(0, items.length - 1)];
const shuffle = (items) => { const copy = [...items]; for (let i = copy.length - 1; i > 0; i--) { const j = int(0, i); [copy[i], copy[j]] = [copy[j], copy[i]]; } return copy; };
const gcd = (a, b) => b ? gcd(b, a % b) : Math.abs(a);
const reduced = (n, d) => { const g = gcd(n, d); return `${n / g}/${d / g}`; };
const rawFraction = ([n, d]) => `${n}/${d}`;
const tenth = (n) => `${n < 0 ? "-" : ""}${Math.floor(Math.abs(n) / 10)}.${Math.abs(n) % 10}`;
const primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59];
const bank = [], seen = new Set(), familyCounts = {};
function add(group, family, values, explanation, options, format = String) {
  const terms = values.slice(0, -1).map(format), answer = format(values.at(-1));
  if (terms.length < 6 || terms.length > 10 || terms.some((x) => x.length > 10) || answer.length > 10) return;
  if (terms.includes(answer)) return;
  if (new Set(terms).size < Math.ceil(terms.length * .65)) return;
  const key = terms.join("|");
  if (seen.has(key)) return;
  const wrong = [...new Set(options.map(format))].filter((x) => x !== answer && !terms.includes(x) && x.length <= 10);
  if (wrong.length < 4) return;
  seen.add(key);
  bank.push({ id: `Q${String(bank.length + 1).padStart(5, "0")}`, group, family, terms, answer, options: shuffle([answer, ...shuffle(wrong).slice(0, 4)]), explanation });
  familyCounts[family] = (familyCounts[family] ?? 0) + 1;
}
function numberOptions(values, extra = []) {
  const answer = values.at(-1), gap = answer - values.at(-2);
  return [answer - 1, answer + 1, answer - 2, answer + 2, answer - 3, answer + 3, answer - 4, answer + 4, answer - gap, answer + gap, ...extra];
}
function fractionOptions([n, d]) {
  return [[n - 1, d], [n + 1, d], [n - 2, d], [n + 2, d], [n, d - 1], [n, d + 1], [n - 3, d], [n + 3, d]];
}
function generate() {
  {
    const count = int(7, 10), first = int(3, 24), d = int(3, 9), step = int(2, 5), values = [first], gaps = [];
    for (let i = 0; i < count; i++) { gaps.push(d + i * step); values.push(values.at(-1) + gaps.at(-1)); }
    add("계차", "증가하는 계차", values, `이웃한 항의 차이는 ${gaps.slice(0, count - 1).join(", ")}입니다. 차이가 매번 ${step}씩 커지므로 다음 차이 ${gaps.at(-1)}를 더하면 ${values.at(-1)}입니다.`, numberOptions(values));
  }
  {
    const count = int(6, 9), first = int(2, 20), d = int(2, 5), values = [first], gaps = [];
    for (let i = 0; i < count; i++) { gaps.push(d * 2 ** i); values.push(values.at(-1) + gaps.at(-1)); }
    add("계차", "두 배씩 커지는 계차", values, `이웃한 항의 차이는 ${gaps.slice(0, count - 1).join(", ")}로 두 배씩 커집니다. 다음 차이는 ${gaps.at(-1)}이므로 정답은 ${values.at(-1)}입니다.`, numberOptions(values, [values.at(-2) + gaps.at(-2) * 3]));
  }
  {
    const count = int(7, 9), c = int(2, 7), values = [int(2, 9), int(4, 14)];
    while (values.length <= count) values.push(values.at(-1) + values.at(-2) + c);
    add("피보나치", "피보나치와 고정 보정", values, `세 번째 항부터 앞의 두 수를 더하고 ${c}를 더합니다. 마지막 두 수 ${values.at(-3)}, ${values.at(-2)}에 같은 규칙을 적용하면 ${values.at(-1)}입니다.`, numberOptions(values, [values.at(-2) + values.at(-3)]));
  }
  {
    const count = int(7, 8), plus = int(2, 6), minus = int(1, 4), values = [int(3, 9), int(6, 14)];
    while (values.length <= count) { const i = values.length; values.push(values.at(-1) + values.at(-2) + (i % 2 === 0 ? plus : -minus)); }
    const correction = count % 2 === 0 ? plus : -minus;
    add("피보나치", "피보나치와 교대 보정", values, `앞의 두 항을 더한 뒤 ${plus}를 더하고 ${minus}를 빼는 보정을 번갈아 적용합니다. 이번에는 ${correction > 0 ? `+${correction}` : correction}를 적용해 ${values.at(-1)}입니다.`, numberOptions(values, [values.at(-2) + values.at(-3)]));
  }
  {
    const count = int(8, 9), a = int(3, 13), b = int(2, 7), da = int(3, 9), mult = pick([2, 3]);
    const values = Array.from({ length: count + 1 }, (_, i) => i % 2 === 0 ? a + (i / 2) * da : b * mult ** Math.floor(i / 2));
    const track = count % 2 === 0 ? `홀수 자리 ${a}, ${a + da}, ${a + 2 * da}…는 ${da}씩 증가` : `짝수 자리 ${b}, ${b * mult}, ${b * mult ** 2}…는 ${mult}배씩 증가`;
    add("홀짝 분리", "홀짝 등차·등비", values, `홀수 자리와 짝수 자리를 분리하세요. ${track}합니다. 다음 수는 ${values.at(-1)}입니다.`, numberOptions(values));
  }
  {
    const count = int(8, 9), a = int(2, 17), b = int(11, 30), da = int(2, 6), db = int(3, 8), sa = int(1, 3), sb = int(1, 3);
    const values = Array.from({ length: count + 1 }, (_, i) => { const j = Math.floor(i / 2); return i % 2 === 0 ? a + j * da + sa * j * (j - 1) / 2 : b + j * db + sb * j * (j - 1) / 2; });
    add("홀짝 분리", "홀짝 독립 계차", values, `홀수 자리와 짝수 자리를 따로 보면 각각의 증가폭이 일정하게 커집니다. 홀수 자리 차이는 처음 ${da}에서 ${sa}씩, 짝수 자리 차이는 처음 ${db}에서 ${sb}씩 커집니다. 다음 수는 ${values.at(-1)}입니다.`, numberOptions(values));
  }
  {
    const count = int(7, 9), first = int(3, 10), mult = pick([2, 3]), sub = int(1, 5), plus = int(4, 8), step = int(1, 3), values = [first];
    for (let i = 0; i < count; i++) values.push(i % 2 === 0 ? values.at(-1) * mult - sub : values.at(-1) + plus + Math.floor(i / 2) * step);
    add("연산 교대", "곱셈·증가하는 덧셈", values, `×${mult}−${sub}와 덧셈을 번갈아 적용합니다. 덧셈 값은 ${plus}부터 ${step}씩 커집니다. 다음 항은 ${values.at(-1)}입니다.`, numberOptions(values, [values.at(-2) * mult - sub]));
  }
  {
    const count = int(7, 9), first = int(13, 30), up = int(8, 15), down = int(3, 8), du = int(1, 3), dd = int(1, 2), values = [first], changes = [];
    for (let i = 0; i < count; i++) { const change = i % 2 === 0 ? up + Math.floor(i / 2) * du : -(down + Math.floor(i / 2) * dd); changes.push(change); values.push(values.at(-1) + change); }
    add("연산 교대", "증감 교대", values, `증가와 감소가 교대로 나타납니다. 증가폭은 ${up}부터 ${du}씩, 감소폭은 ${down}부터 ${dd}씩 커집니다. 다음 변화는 ${changes.at(-1) > 0 ? "+" : ""}${changes.at(-1)}이므로 ${values.at(-1)}입니다.`, numberOptions(values));
  }
  {
    const count = int(7, 9), denominator = pick([12, 18, 24, 30, 36, 60]), a = int(3, 9), d = int(3, 7), step = int(1, 3);
    const numerators = Array.from({ length: count + 1 }, (_, i) => a + d * i + step * i * (i - 1) / 2);
    const values = numerators.map((n) => [n, denominator]);
    const terms = values.slice(0, -1).map(([n, d]) => reduced(n, d));
    if (new Set(terms.map((x) => x.split("/")[1])).size >= 3) add("분수 통분", "통분 후 분자 계차", values, `모든 항을 분모 ${denominator}으로 통분하면 분자가 ${numerators.slice(0, count).join(", ")}가 됩니다. 분자 사이의 차이가 ${step}씩 커지므로 다음 분자는 ${numerators.at(-1)}, 정답은 ${reduced(numerators.at(-1), denominator)}입니다.`, fractionOptions(values.at(-1)), ([n,d]) => reduced(n,d));
  }
  {
    const count = int(7, 8), denominator = pick([24, 30, 36, 60]), correction = int(1, 4), nums = [int(3, 7), int(5, 11)];
    while (nums.length <= count) nums.push(nums.at(-1) + nums.at(-2) + correction);
    const values = nums.map((n) => [n, denominator]);
    const terms = values.slice(0, -1).map(([n, d]) => reduced(n, d));
    if (new Set(terms.map((x) => x.split("/")[1])).size >= 3) add("분수 통분", "통분 후 분자 재귀", values, `분모를 ${denominator}으로 통분하면 분자는 ${nums.slice(0, count).join(", ")}입니다. 앞의 두 분자를 더하고 ${correction}를 더하므로 다음 분자는 ${nums.at(-1)}, 정답은 ${reduced(nums.at(-1), denominator)}입니다.`, fractionOptions(values.at(-1)), ([n,d]) => reduced(n,d));
  }
  {
    const count = int(7, 9), n0 = int(3, 12), d0 = int(11, 24), nstep = int(2, 6), nacc = int(1, 3), dstep = int(2, 5);
    const values = Array.from({ length: count + 1 }, (_, i) => [n0 + i * nstep + nacc * i * (i - 1) / 2, d0 + i * dstep]);
    add("분자·분모", "분자 계차·분모 등차", values, `분자와 분모를 따로 보세요. 분자는 첫 증가폭 ${nstep}에서 차이가 ${nacc}씩 커지고, 분모는 ${dstep}씩 증가합니다. 다음 항은 ${rawFraction(values.at(-1))}입니다.`, fractionOptions(values.at(-1)), rawFraction);
  }
  {
    const count = int(7, 8), d0 = int(9, 19), dstep = int(2, 5), correction = int(1, 3), nums = [int(2, 7), int(5, 11)];
    while (nums.length <= count) nums.push(nums.at(-1) + nums.at(-2) + correction);
    const values = nums.map((n, i) => [n, d0 + i * dstep]);
    add("분자·분모", "분자 피보나치·분모 등차", values, `분자는 앞의 두 분자를 더하고 ${correction}를 더합니다. 분모는 ${dstep}씩 증가합니다. 다음 항은 ${rawFraction(values.at(-1))}입니다.`, fractionOptions(values.at(-1)), rawFraction);
  }
  {
    const count = int(7, 9), first = int(8, 34), d = int(3, 8), step = int(1, 3), values = [first], gaps = [];
    for (let i = 0; i < count; i++) { gaps.push(d + i * step); values.push(values.at(-1) + gaps.at(-1)); }
    add("소수점", "소수점 계차", values, `각 수를 소수 첫째 자리까지 보면 이웃한 차이가 ${gaps.slice(0, count - 1).map(tenth).join(", ")}로 ${tenth(step)}씩 증가합니다. 다음 수는 ${tenth(values.at(-1))}입니다.`, numberOptions(values), tenth);
  }
  {
    const count = int(7, 9), start = int(2, 7), digit = int(1, 8), digitStep = pick([2, 3, 4]), wholeStep = int(2, 4);
    const values = Array.from({ length: count + 1 }, (_, i) => 10 * (start + i * wholeStep) + (digit + i * digitStep) % 10);
    add("소수점", "정수부·소수부 분리", values, `소수점 왼쪽은 ${wholeStep}씩 증가하고, 오른쪽 한 자리 숫자는 ${digitStep}씩 증가한 뒤 10에서 다시 시작합니다. 다음 수는 ${tenth(values.at(-1))}입니다.`, numberOptions(values, [values.at(-1) + 10, values.at(-1) - 10]), tenth);
  }
  {
    const a = int(2, 9), b = int(4, 12), da = int(2, 6), db = int(2, 5), values = [];
    for (let i = 0; i < 3; i++) { const x = a + i * da, y = b + i * db; values.push(x, y, x + y); }
    const answer = values[6] + values[7];
    add("군수열", "세 수 묶음 합", [...values.slice(0, 8), answer], `세 수씩 묶으면 세 번째 수는 앞의 두 수의 합입니다. 첫 수는 ${da}씩, 둘째 수는 ${db}씩 커집니다. 마지막 묶음은 ${values[6]}+${values[7]}=${answer}입니다.`, numberOptions([...values.slice(0, 8), answer]));
  }
  {
    const a = int(2, 5), b = int(3, 7), da = int(1, 3), db = int(1, 2), c = int(1, 5), values = [];
    for (let i = 0; i < 3; i++) { const x = a + i * da, y = b + i * db; values.push(x, y, x * y + c); }
    const answer = values[6] * values[7] + c;
    add("군수열", "세 수 묶음 곱", [...values.slice(0, 8), answer], `세 수씩 묶으면 세 번째 수는 앞의 두 수를 곱하고 ${c}를 더한 값입니다. 마지막 묶음은 ${values[6]}×${values[7]}+${c}=${answer}입니다.`, numberOptions([...values.slice(0, 8), answer]));
  }
  {
    const count = int(8, 9), start = int(2, 7), plus = int(1, 6), minus = int(1, 5);
    const values = Array.from({ length: count + 1 }, (_, i) => (start + i) ** 2 + (i % 2 === 0 ? plus : -minus));
    add("제곱수", "제곱수·교대 보정", values, `기본 수는 ${start}², ${start + 1}², ${start + 2}²…입니다. 홀수 자리에는 ${plus}를 더하고 짝수 자리에는 ${minus}를 빼는 보정을 번갈아 적용합니다. 다음 수는 ${values.at(-1)}입니다.`, numberOptions(values, [(start + count) ** 2]));
  }
  {
    const count = int(6, 10), start = int(2, 18), c = int(2, 16);
    const values = Array.from({ length: count + 1 }, (_, i) => (start + i) ** 2 + (start + i + 1) ** 2 + c);
    add("제곱수", "연속 제곱의 합", values, `연속한 두 자연수의 제곱을 더한 뒤 ${c}를 더합니다. 마지막 항은 ${start + count}²+${start + count + 1}²+${c}=${values.at(-1)}입니다.`, numberOptions(values, [(start + count) ** 2 + (start + count + 1) ** 2]));
  }
  {
    const count = int(7, 9), first = int(5, 60), p0 = int(1, 7), values = [first], used = [];
    for (let i = 0; i < count; i++) { used.push(primes[p0 + i]); values.push(values.at(-1) + used.at(-1)); }
    add("소수(素數)", "소수만큼 증가", values, `차이를 구하면 ${used.slice(0, count - 1).join(", ")}로 연속한 소수입니다. 다음 소수 ${used.at(-1)}를 더하면 ${values.at(-1)}입니다.`, numberOptions(values));
  }
  {
    const count = int(6, 9), p0 = int(0, 3), factor = int(2, 5), step = int(1, 2), correction = int(1, 5);
    const values = Array.from({ length: count + 1 }, (_, i) => primes[p0 + i] * (factor + i * step) + correction);
    add("소수(素數)", "소수와 배수의 결합", values, `각 항에서 연속한 소수 ${primes.slice(p0, p0 + count).join(", ")}에 ${factor}, ${factor + step}, ${factor + 2 * step}…을 곱하고 ${correction}를 더합니다. 다음 수는 ${values.at(-1)}입니다.`, numberOptions(values, [primes[p0 + count] * (factor + count * step)]));
  }
  {
    const count = int(7, 9), first = int(3, 10), correction = int(1, 5), increase = int(1, 3), values = [first];
    for (let i = 0; i < count; i++) values.push(values.at(-1) * 2 + correction + i * increase);
    add("곱셈 성장", "두 배와 증가하는 보정", values, `앞 항을 두 배로 한 뒤 ${correction}, ${correction + increase}, ${correction + 2 * increase}…을 차례로 더합니다. 다음 수는 ${values.at(-1)}입니다.`, numberOptions(values, [values.at(-2) * 2 + correction]));
  }
  {
    const count = int(6, 8), first = int(2, 15), correction = int(1, 7), values = [first], multipliers = [];
    for (let i = 0; i < count; i++) { const m = 2 + Math.floor(i / 2); multipliers.push(m); values.push(values.at(-1) * m - correction); }
    add("곱셈 성장", "두 번씩 바뀌는 곱", values, `곱하는 수는 ${multipliers.slice(0, count - 1).join(", ")}처럼 두 번마다 1씩 커지고, 매번 ${correction}를 뺍니다. 다음 곱수 ${multipliers.at(-1)}를 적용하면 ${values.at(-1)}입니다.`, numberOptions(values, [values.at(-2) * multipliers.at(-1)]));
  }
  {
    const count = int(7, 9), correction = int(1, 4), magnitudes = [int(2, 7), int(4, 9)];
    while (magnitudes.length <= count) magnitudes.push(magnitudes.at(-1) + magnitudes.at(-2) + correction);
    const values = magnitudes.map((n, i) => i % 2 === 0 ? n : -n);
    add("부호 교대", "부호 교대 피보나치", values, `부호는 +, −로 교대합니다. 절댓값은 앞의 두 절댓값을 더하고 ${correction}를 더합니다. 다음 수는 ${values.at(-1)}입니다.`, numberOptions(values));
  }
  {
    const count = int(6, 10), start = int(2, 18), offset = int(1, 15), values = Array.from({ length: count + 1 }, (_, i) => (i % 2 === 0 ? 1 : -1) * ((start + i) ** 2 + offset));
    add("부호 교대", "부호 교대 제곱", values, `부호는 +, −로 교대하고 절댓값은 ${start}²+${offset}, ${start + 1}²+${offset}…입니다. 다음 수는 ${values.at(-1)}입니다.`, numberOptions(values));
  }
}
for (let i = 0; i < 360; i++) generate();
const groups = [...new Set(bank.map((q) => q.group))];
const meta = { total: bank.length, groupCount: groups.length, familyCount: Object.keys(familyCounts).length, groups, familyCounts, termLengths: [...new Set(bank.map((q) => q.terms.length))].sort((a, b) => a - b) };
writeFileSync(join(root, "lib", "bank.json"), JSON.stringify(bank));
writeFileSync(join(root, "lib", "bank-meta.json"), JSON.stringify(meta));
console.log(JSON.stringify(meta));
