import { writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

// All questions are original and generated from algebraic rules, not copied examples.
const root = join(dirname(fileURLToPath(import.meta.url)), "..");
let state = 0x5c7c2026;
const rand = () => ((state = (Math.imul(state, 1664525) + 1013904223) >>> 0) / 4294967296);
const int = (a,b) => a + Math.floor(rand() * (b-a+1));
const gcd = (a,b) => b ? gcd(b,a%b) : a;
const frac = (n,d) => { const g=gcd(n,d); return `${n/g}/${d/g}`; };
const shuffle = a => { for(let i=a.length-1;i>0;i--){const j=int(0,i);[a[i],a[j]]=[a[j],a[i]]}return a; };
const bank=[]; const seen=new Set();
function add(family, terms, answer, explanation, variants) {
  if (terms.some(x => String(x).length>8) || String(answer).length>8) return;
  const key=terms.join(",");
  if(seen.has(key))return; seen.add(key);
  const wrong=[...new Set(variants.map(String))].filter(x=>x!==String(answer) && !terms.includes(x));
  if(wrong.length<4)return;
  const options=shuffle([String(answer),...shuffle(wrong).slice(0,4)]);
  bank.push({id:`Q${String(bank.length+1).padStart(4,"0")}`,family,terms:terms.map(String),answer:String(answer),options,explanation});
}
for(let k=0;k<400;k++){
  { // Odd and even positions obey separate, accelerating rules.
    const a=int(2,18), b=int(11,35), d=int(2,8), e=int(3,10), u=int(1,4), v=int(1,4);
    const terms=Array.from({length:8},(_,i)=>i%2===0?a+(i/2)*d+u*(i/2)*(i/2):b+Math.floor(i/2)*e+v*Math.floor(i/2)**2);
    const answer=a+4*d+16*u;
    add("교대·이차",terms,answer,`홀수 자리와 짝수 자리를 따로 보면, 홀수 자리 수는 ${a}에서 시작해 차이가 ${d+u}, ${d+3*u}, ${d+5*u}, ${d+7*u}로 증가합니다. 따라서 다음 수는 ${answer}입니다.`,[answer-d,answer+d,answer-u,answer+u,answer+2*u,answer-2*u]);
  }
  { // Differences interleave two changing tracks.
    const first=int(3,25), a=int(2,9), b=int(4,14), u=int(1,4), v=int(1,5);
    const diffs=Array.from({length:8},(_,i)=>i%2===0?a+Math.floor(i/2)*u:b+Math.floor(i/2)*v);
    const terms=[first]; for(let i=0;i<7;i++)terms.push(terms.at(-1)+diffs[i]);
    const answer=terms.at(-1)+diffs[7];
    add("교대 차이",terms,answer,`연속한 수의 차이를 구하면 ${diffs.slice(0,7).join(", ")}입니다. 차이의 홀수 번째와 짝수 번째가 각각 일정하게 증가하므로 다음 차이는 ${diffs[7]}, 정답은 ${answer}입니다.`,[answer-u,answer+u,answer-v,answer+v,answer-a,answer+b]);
  }
  { // Second differences themselves grow arithmetically.
    const first=int(2,22), d=int(2,9), s=int(2,7), t=int(1,4);
    const terms=[first]; let delta=d; for(let i=0;i<7;i++){terms.push(terms.at(-1)+delta);delta+=s+i*t;}
    const answer=terms.at(-1)+delta;
    add("변화하는 2차 차이",terms,answer,`1차 차이의 변화량은 ${Array.from({length:7},(_,i)=>s+i*t).join(", ")}로 일정하게 ${t}씩 커집니다. 다음 차이를 적용하면 ${answer}입니다.`,[answer-s,answer+s,answer-t,answer+t,answer-d,answer+d]);
  }
  { // Two distinct operations alternate, with increasing additions.
    const first=int(2,10), mult=int(2,3), sub=int(1,5), plus=int(3,9), step=int(1,4);
    const terms=[first]; for(let i=0;i<7;i++)terms.push(i%2===0?terms.at(-1)*mult-sub:terms.at(-1)+plus+Math.floor(i/2)*step);
    const answer=terms.at(-1)+plus+3*step;
    add("곱셈·덧셈 교대",terms,answer,`×${mult}−${sub}와 덧셈을 번갈아 적용합니다. 덧셈은 ${plus}, ${plus+step}, ${plus+2*step}, ${plus+3*step}로 변하므로 다음 수는 ${answer}입니다.`,[answer-step,answer+step,answer-plus,answer+plus,terms.at(-1)*mult-sub,answer+2*step]);
  }
  { // Fractions have independent numerator/denominator rules.
    const n=int(2,8), d=int(9,17), ni=int(3,7), di=int(2,5), ns=int(1,3);
    const raw=Array.from({length:9},(_,i)=>[n+i*ni+ns*i*i,d+i*di]);
    const terms=raw.slice(0,8).map(([x,y])=>frac(x,y)); const answer=frac(...raw[8]);
    const variants=[frac(raw[8][0]-ni,raw[8][1]),frac(raw[8][0]+ni,raw[8][1]),frac(raw[8][0],raw[8][1]-di),frac(raw[8][0],raw[8][1]+di),frac(raw[8][0]-ns,raw[8][1]),frac(raw[8][0]+ns,raw[8][1])];
    add("분수·분자 분모",terms,answer,`분자와 분모를 따로 보세요. 분자는 n번째에서 ${n}+${ni}n+${ns}n², 분모는 ${d}+${di}n (첫 항 n=0)입니다. 다음 항은 ${answer}입니다.`,variants);
  }
  { // Recurrence with alternating correction.
    const a=int(2,8), b=int(5,13), c=int(1,5), u=int(1,3);
    const terms=[a,b];for(let i=2;i<8;i++)terms.push(terms[i-1]+terms[i-2]+c+Math.floor((i-2)/2)*u*(i%2===0?1:-1));
    const i=8,answer=terms[7]+terms[6]+c+3*u;
    add("앞 두 항 결합",terms,answer,`앞 두 항을 더한 뒤 보정값을 더합니다. 보정값은 짝수·홀수 위치에서 서로 다르게 움직입니다. 다음 보정값은 ${c+3*u}이므로 ${terms[7]}+${terms[6]}+${c+3*u}=${answer}입니다.`,[answer-u,answer+u,answer-c,answer+c,answer-2*u,answer+2*u]);
  }
}
const counts=Object.fromEntries([...new Set(bank.map(q=>q.family))].map(f=>[f,bank.filter(q=>q.family===f).length]));
writeFileSync(join(root,"lib","bank.json"),JSON.stringify(bank));
console.log(JSON.stringify({total:bank.length,counts}));
