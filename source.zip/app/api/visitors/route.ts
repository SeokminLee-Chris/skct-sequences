import { db, corsJson, errorResponse, preflight } from "@/lib/store";
import { todayInSeoul } from "@/lib/daily";

export const OPTIONS = preflight;

async function counts(day: string) {
  const [today, total] = await db().batch([
    db().prepare("SELECT COUNT(*) AS count FROM visitor_days WHERE day = ?").bind(day),
    db().prepare("SELECT COUNT(*) AS count FROM visitors"),
  ]);
  return { day, today: Number((today.results[0] as { count: number } | undefined)?.count ?? 0), total: Number((total.results[0] as { count: number } | undefined)?.count ?? 0) };
}

export async function GET() {
  try { return corsJson(await counts(todayInSeoul())); }
  catch (error) { return errorResponse(error); }
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as { visitorId?: string };
    if (!body.visitorId || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(body.visitorId)) {
      return corsJson({ error: "방문자 정보가 올바르지 않습니다." }, { status: 400 });
    }
    const day = todayInSeoul();
    await db().batch([
      db().prepare("INSERT OR IGNORE INTO visitors (id, first_seen) VALUES (?, ?)").bind(body.visitorId, day),
      db().prepare("INSERT OR IGNORE INTO visitor_days (visitor_id, day) VALUES (?, ?)").bind(body.visitorId, day),
    ]);
    return corsJson(await counts(day));
  } catch (error) { return errorResponse(error); }
}
