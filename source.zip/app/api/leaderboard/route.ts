import { db, errorResponse, corsJson, preflight } from "@/lib/store";
export const OPTIONS = preflight;
export async function GET() {
  try {
    const result = await db().prepare("SELECT nickname, correct, score, (finished_at - started_at) / 1000 AS seconds FROM runs WHERE finished_at IS NOT NULL AND nickname IS NOT NULL ORDER BY score DESC, seconds ASC LIMIT 20").all();
    return corsJson({ entries: result.results });
  } catch (error) { return errorResponse(error); }
}
