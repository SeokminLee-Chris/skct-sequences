import { db, errorResponse, corsJson, preflight } from "@/lib/store";
export const OPTIONS = preflight;
export async function GET(request: Request) {
  try {
    const total = new URL(request.url).searchParams.get("total") === "20" ? 20 : 10;
    const result = await db().prepare("SELECT nickname, correct, correct * 100 AS score, COALESCE(NULLIF(elapsed_ms, 0), finished_at - started_at) / 1000.0 AS seconds FROM runs WHERE finished_at IS NOT NULL AND nickname IS NOT NULL AND json_array_length(question_ids) = ? ORDER BY correct DESC, seconds ASC LIMIT 20").bind(total).all();
    return corsJson({ entries: result.results });
  } catch (error) { return errorResponse(error); }
}
