import { corsJson, errorResponse, preflight } from "@/lib/store";
import { getDailyRun, finishExpired } from "@/lib/daily-run";
export const OPTIONS = preflight;
export async function POST(request: Request) {
  try {
    const body = await request.json() as { runId?: string };
    if (!body.runId) return corsJson({ error: "도전 정보가 없습니다." }, { status: 400 });
    const run = await getDailyRun(body.runId);
    if (!run) return corsJson({ error: "진행 중인 Test를 찾을 수 없습니다." }, { status: 404 });
    if (run.finished_at !== null) {
      if (run.elapsed_ms >= 15 * 60 * 1000) {
        const { dailyReview } = await import("@/lib/daily");
        return corsJson({ timedOut: true, done: true, correctCount: run.correct, score: run.correct * 100, position: run.position, total: 20, durationSeconds: 900, review: dailyReview(JSON.parse(run.question_ids), JSON.parse(run.choices_json)) });
      }
      return corsJson({ error: "이미 완료된 Test입니다." }, { status: 409 });
    }
    const result = await finishExpired(run);
    return result ? corsJson(result) : corsJson({ error: "아직 제한 시간이 남아 있습니다." }, { status: 409 });
  } catch (error) { return errorResponse(error); }
}
