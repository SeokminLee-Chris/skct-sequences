import { db, corsJson, errorResponse, preflight } from "@/lib/store";
import { DAILY_TEST_COUNT, dailyKey, todayInSeoul } from "@/lib/daily";
export const OPTIONS = preflight;
export async function GET(request: Request) {
  try {
    const test = Number(new URL(request.url).searchParams.get("test"));
    if (!Number.isInteger(test) || test < 1 || test > DAILY_TEST_COUNT) return corsJson({ error: "Test 1~10 중 하나를 선택해 주세요." }, { status: 400 });
    const date = todayInSeoul();
    const result = await db().prepare("SELECT nickname, correct, correct * 100 AS score, COALESCE(NULLIF(elapsed_ms, 0), finished_at - started_at) / 1000.0 AS seconds FROM daily_runs WHERE test_key = ? AND finished_at IS NOT NULL AND nickname IS NOT NULL ORDER BY correct DESC, seconds ASC LIMIT 20")
      .bind(dailyKey(date, test)).all();
    return corsJson({ date, test, entries: result.results });
  } catch (error) { return errorResponse(error); }
}
