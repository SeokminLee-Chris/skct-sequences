import { db, corsJson, errorResponse, preflight } from "@/lib/store";
import { DAILY_LIMIT_MS, DAILY_TEST_COUNT, dailyKey, dailyTests, todayInSeoul } from "@/lib/daily";
import { publicQuestion } from "@/lib/questions";

export const OPTIONS = preflight;
export function GET() {
  return corsJson({ date: todayInSeoul(), testCount: DAILY_TEST_COUNT, limitSeconds: DAILY_LIMIT_MS / 1000 });
}
export async function POST(request: Request) {
  try {
    const body = await request.json() as { test?: number };
    if (!Number.isInteger(body.test) || (body.test as number) < 1 || (body.test as number) > DAILY_TEST_COUNT) return corsJson({ error: "Test 1~10 중 하나를 선택해 주세요." }, { status: 400 });
    const date = todayInSeoul(), test = body.test as number;
    const picked = dailyTests(date)[test - 1];
    const id = crypto.randomUUID(), started = Date.now();
    await db().prepare("INSERT INTO daily_runs (id, test_key, question_ids, started_at) VALUES (?, ?, ?, ?)")
      .bind(id, dailyKey(date, test), JSON.stringify(picked.map((q) => q.id)), started).run();
    return corsJson({ runId: id, question: publicQuestion(picked[0]), position: 0, total: 20, date, test, deadlineAt: started + DAILY_LIMIT_MS });
  } catch (error) { return errorResponse(error); }
}
