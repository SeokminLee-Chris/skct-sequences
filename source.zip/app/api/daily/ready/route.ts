import { db, corsJson, errorResponse, preflight } from "@/lib/store";
import { DAILY_LIMIT_MS } from "@/lib/daily";
import { elapsedMs, finishExpired, getDailyRun } from "@/lib/daily-run";
export const OPTIONS = preflight;

export async function POST(request: Request) {
  try {
    const body = await request.json() as { runId?: string; position?: number };
    if (!body.runId || !Number.isInteger(body.position)) return corsJson({ error: "문제 정보가 없습니다." }, { status: 400 });
    const run = await getDailyRun(body.runId);
    if (!run || run.finished_at !== null || run.position !== body.position) return corsJson({ error: "진행 중인 Test를 찾을 수 없습니다." }, { status: 409 });
    const expired = await finishExpired(run);
    if (expired) return corsJson(expired);
    const now = Date.now();
    await db().prepare("UPDATE daily_runs SET active_since = ? WHERE id = ? AND position = ? AND active_since IS NULL AND finished_at IS NULL")
      .bind(now, run.id, run.position).run();
    const latest = await getDailyRun(run.id);
    if (!latest) throw new Error("Daily run vanished");
    return corsJson({ remainingMs: Math.max(0, DAILY_LIMIT_MS - elapsedMs(latest, now)) });
  } catch (error) { return errorResponse(error); }
}
