import { db, corsJson, errorResponse, preflight } from "@/lib/store";
import { getDailyRun, finishExpired, elapsedMs } from "@/lib/daily-run";
import { dailyReview } from "@/lib/daily";
import { publicQuestion, questionById } from "@/lib/questions";
export const OPTIONS = preflight;

export async function POST(request: Request) {
  try {
    const body = await request.json() as { runId?: string; questionId?: string; choice?: number };
    if (!body.runId || !body.questionId || !Number.isInteger(body.choice) || (body.choice as number) < -1 || (body.choice as number) > 4) return corsJson({ error: "답안을 확인해 주세요." }, { status: 400 });
    const run = await getDailyRun(body.runId);
    if (!run || run.finished_at !== null) return corsJson({ error: "진행 중인 Test를 찾을 수 없습니다." }, { status: 404 });
    const expired = await finishExpired(run);
    if (expired) return corsJson(expired);
    const ids = JSON.parse(run.question_ids) as string[];
    const q = questionById.get(ids[run.position]);
    if (!q || q.id !== body.questionId) return corsJson({ error: "현재 문제와 답안이 일치하지 않습니다." }, { status: 409 });
    const choice = body.choice as number, correct = choice >= 0 && q.options[choice] === q.answer;
    const position = run.position + 1, done = position === ids.length, now = Date.now();
    const choices = [...JSON.parse(run.choices_json) as (number | null)[], choice < 0 ? null : choice];
    const durationMs = elapsedMs(run, now);
    const result = await db().prepare("UPDATE daily_runs SET choices_json = ?, position = ?, correct = ?, elapsed_ms = ?, active_since = NULL, finished_at = ? WHERE id = ? AND position = ? AND finished_at IS NULL AND active_since IS NOT NULL")
      .bind(JSON.stringify(choices), position, run.correct + Number(correct), durationMs, done ? now : null, run.id, run.position).run();
    if (!result.meta.changes) {
      const expiredAfterCheck = await finishExpired(run);
      return expiredAfterCheck ? corsJson(expiredAfterCheck) : corsJson({ error: "이미 제출된 답안입니다." }, { status: 409 });
    }
    if (done) return corsJson({ done: true, timedOut: false, position, total: 20, correctCount: run.correct + Number(correct), score: (run.correct + Number(correct)) * 100, durationSeconds: durationMs / 1000, review: dailyReview(ids, choices) });
    const next = questionById.get(ids[position]);
    return corsJson({ done: false, position, total: 20, nextQuestion: next ? publicQuestion(next) : null });
  } catch (error) { return errorResponse(error); }
}
