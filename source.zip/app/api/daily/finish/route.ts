import { db, corsJson, errorResponse, preflight } from "@/lib/store";
export const OPTIONS = preflight;
export async function POST(request: Request) {
  try {
    const body = await request.json() as { runId?: string; nickname?: string };
    const nickname = body.nickname?.trim().replace(/\s+/g, " ") ?? "";
    if (!body.runId || nickname.length < 2 || nickname.length > 16 || /[<>]/.test(nickname)) return corsJson({ error: "닉네임을 2~16자로 입력해 주세요." }, { status: 400 });
    const result = await db().prepare("UPDATE daily_runs SET nickname = ? WHERE id = ? AND finished_at IS NOT NULL AND nickname IS NULL")
      .bind(nickname, body.runId).run();
    if (!result.meta.changes) return corsJson({ error: "완료된 Test를 찾지 못했거나 이미 등록됐습니다." }, { status: 409 });
    return corsJson({ saved: true });
  } catch (error) { return errorResponse(error); }
}
