import { db, errorResponse, corsJson, preflight } from "@/lib/store";
export const OPTIONS = preflight;
import { publicQuestion, questionById } from "@/lib/questions";
type Run = { question_ids: string; position: number; correct: number; score: number; elapsed_ms: number; active_since: number | null; finished_at: number | null };
export async function POST(request: Request) {
  try {
    const body = await request.json() as { runId?: string; questionId?: string; choice?: number };
    if (!body.runId || !body.questionId || !Number.isInteger(body.choice) || (body.choice as number) < 0 || (body.choice as number) > 4) return corsJson({ error: "답안을 확인해 주세요." }, { status: 400 });
    const run = await db().prepare("SELECT question_ids, position, correct, score, elapsed_ms, active_since, finished_at FROM runs WHERE id = ?").bind(body.runId).first<Run>();
    if (!run || run.finished_at !== null) return corsJson({ error: "진행 중인 도전을 찾을 수 없습니다." }, { status: 404 });
    if (run.active_since === null) return corsJson({ error: "문제가 준비되지 않았습니다." }, { status: 409 });
    const ids = JSON.parse(run.question_ids) as string[];
    const q = questionById.get(ids[run.position]);
    if (!q || q.id !== body.questionId) return corsJson({ error: "현재 문제와 답안이 일치하지 않습니다." }, { status: 409 });
    const now = Date.now();
    const correct = q.options[body.choice as number] === q.answer;
    const gained = correct ? 100 : 0;
    const nextPosition = run.position + 1, done = nextPosition >= ids.length;
    const durationMs = run.elapsed_ms + Math.max(0, now - run.active_since);
    const result = await db().prepare("UPDATE runs SET position = ?, correct = ?, score = ?, elapsed_ms = ?, active_since = NULL, question_started_at = ?, finished_at = ? WHERE id = ? AND position = ? AND active_since IS NOT NULL AND finished_at IS NULL")
      .bind(nextPosition, run.correct + Number(correct), run.score + gained, durationMs, now, done ? now : null, body.runId, run.position).run();
    if (!result.meta.changes) return corsJson({ error: "이미 제출된 답안입니다." }, { status: 409 });
    const next = done ? null : questionById.get(ids[nextPosition]);
    return corsJson({ correct, answer: q.answer, explanation: q.explanation, gained, score: run.score + gained, correctCount: run.correct + Number(correct), position: nextPosition, total: ids.length, done, durationSeconds: done ? Math.round(durationMs / 1000) : null, nextQuestion: next ? publicQuestion(next) : null });
  } catch (error) { return errorResponse(error); }
}
