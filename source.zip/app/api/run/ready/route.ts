import { db, corsJson, errorResponse, preflight } from "@/lib/store";
export const OPTIONS = preflight;

export async function POST(request: Request) {
  try {
    const body = await request.json() as { runId?: string; position?: number };
    if (!body.runId || !Number.isInteger(body.position)) return corsJson({ error: "문제 정보가 없습니다." }, { status: 400 });
    const now = Date.now();
    await db().prepare("UPDATE runs SET active_since = ? WHERE id = ? AND position = ? AND active_since IS NULL AND finished_at IS NULL")
      .bind(now, body.runId, body.position).run();
    const run = await db().prepare("SELECT elapsed_ms, active_since FROM runs WHERE id = ? AND position = ? AND finished_at IS NULL").bind(body.runId, body.position).first<{ elapsed_ms: number; active_since: number | null }>();
    if (!run || run.active_since === null) return corsJson({ error: "진행 중인 도전을 찾을 수 없습니다." }, { status: 409 });
    return corsJson({ ready: true, elapsedMs: run.elapsed_ms + Math.max(0, now - run.active_since) });
  } catch (error) { return errorResponse(error); }
}
