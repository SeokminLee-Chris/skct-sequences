import { db, errorResponse, corsJson, preflight } from "@/lib/store";
export const OPTIONS = preflight;
import { pickQuestions, publicQuestion, questions } from "@/lib/questions";
export async function POST() {
  try {
    const picked = pickQuestions(10), id = crypto.randomUUID(), now = Date.now();
    await db().prepare("INSERT INTO runs (id, question_ids, position, correct, score, started_at, question_started_at) VALUES (?, ?, 0, 0, 0, ?, ?)").bind(id, JSON.stringify(picked.map((q) => q.id)), now, now).run();
    return corsJson({ runId: id, question: publicQuestion(picked[0]), position: 0, total: 10, bankSize: questions.length });
  } catch (error) { return errorResponse(error); }
}
