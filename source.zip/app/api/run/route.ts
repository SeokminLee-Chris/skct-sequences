import { db, errorResponse, corsJson, preflight } from "@/lib/store";
export const OPTIONS = preflight;
import { pickQuestions, publicQuestion, questions } from "@/lib/questions";
export async function POST(request: Request) {
  try {
    const body = await request.json() as { total?: number };
    const total = body.total === 20 ? 20 : body.total === 10 ? 10 : null;
    if (!total) return corsJson({ error: "10문항 또는 20문항을 선택해 주세요." }, { status: 400 });
    const picked = pickQuestions(total), id = crypto.randomUUID(), now = Date.now();
    await db().prepare("INSERT INTO runs (id, question_ids, position, correct, score, started_at, question_started_at) VALUES (?, ?, 0, 0, 0, ?, ?)").bind(id, JSON.stringify(picked.map((q) => q.id)), now, now).run();
    return corsJson({ runId: id, question: publicQuestion(picked[0]), position: 0, total, bankSize: questions.length });
  } catch (error) { return errorResponse(error); }
}
