"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

type Question = { id: string; family: string; terms: string[]; options: string[] };
type Entry = { nickname: string; correct: number; score: number; seconds: number };
type Feedback = { correct: boolean; answer: string; explanation: string; gained: number; score: number; correctCount: number; position: number; done: boolean; durationSeconds: number | null; nextQuestion: Question | null };
type Run = { runId: string; question: Question; position: number; total: number };
const API_BASE = typeof document === "undefined" ? "" : document.querySelector<HTMLMetaElement>('meta[name="api-base"]')?.content ?? "";

function Scratchpads() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const [memo, setMemo] = useState("");
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const resize = () => {
      const snapshot = document.createElement("canvas");
      snapshot.width = canvas.width; snapshot.height = canvas.height;
      snapshot.getContext("2d")?.drawImage(canvas, 0, 0);
      const width = Math.max(1, Math.round(canvas.clientWidth * devicePixelRatio));
      const height = Math.max(1, Math.round(canvas.clientHeight * devicePixelRatio));
      if (canvas.width === width && canvas.height === height) return;
      canvas.width = width; canvas.height = height;
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, width, height);
      ctx.drawImage(snapshot, 0, 0);
      ctx.strokeStyle = "#163f35"; ctx.lineWidth = 2.5 * devicePixelRatio;
      ctx.lineCap = "round"; ctx.lineJoin = "round";
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    return () => observer.disconnect();
  }, []);
  function point(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return { x: (event.clientX - rect.left) * canvas.width / rect.width, y: (event.clientY - rect.top) * canvas.height / rect.height };
  }
  function down(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    canvas.setPointerCapture(event.pointerId); drawing.current = true;
    const p = point(event); ctx.beginPath(); ctx.moveTo(p.x, p.y);
  }
  function move(event: React.PointerEvent<HTMLCanvasElement>) {
    if (!drawing.current) return;
    const ctx = canvasRef.current?.getContext("2d"); if (!ctx) return;
    const p = point(event); ctx.lineTo(p.x, p.y); ctx.stroke();
  }
  function clearDrawing() {
    const canvas = canvasRef.current, ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
  return <div className="scratchpads">
    <div className="scratch-card"><div className="scratch-head"><strong>그림판</strong><button onClick={clearDrawing}>지우기</button></div><canvas ref={canvasRef} onPointerDown={down} onPointerMove={move} onPointerUp={() => drawing.current = false} onPointerCancel={() => drawing.current = false} aria-label="마우스나 터치로 풀이를 그리는 그림판" /></div>
    <div className="scratch-card"><div className="scratch-head"><strong>메모장</strong><button onClick={() => setMemo("")}>비우기</button></div><Textarea aria-label="풀이 메모장" placeholder="생각한 규칙이나 계산을 적어보세요." value={memo} onChange={(event) => setMemo(event.target.value)} /></div>
  </div>;
}

async function post<T>(url: string, body?: object): Promise<T> {
  const response = await fetch(API_BASE + url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body ?? {}) });
  const data = await response.json() as { error?: string };
  if (!response.ok) throw new Error(data.error ?? "요청에 실패했습니다.");
  return data as T;
}

export default function Home() {
  const [view, setView] = useState("practice");
  const [run, setRun] = useState<Run | null>(null);
  const [choice, setChoice] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [seconds, setSeconds] = useState(0);
  const [score, setScore] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [nickname, setNickname] = useState("");
  const [saved, setSaved] = useState(false);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [leaderboardError, setLeaderboardError] = useState("");

  const loadLeaderboard = useCallback(async () => {
    try {
      const response = await fetch(API_BASE + "/api/leaderboard", { cache: "no-store" });
      const data = await response.json() as { error?: string; entries?: Entry[] };
      if (!response.ok) throw new Error(data.error);
      setEntries(data.entries ?? []);
      setLeaderboardError("");
    } catch { setLeaderboardError("순위를 불러오지 못했습니다."); }
  }, []);

  const start = useCallback(async () => {
    setBusy(true); setError(""); setChoice(null); setFeedback(null); setScore(0); setCorrectCount(0); setSaved(false); setSeconds(0);
    try {
      const next = await post<Run>("/api/run");
      setRun(next);
      setView("practice");
    } catch (e) { setError(e instanceof Error ? e.message : "문제를 불러오지 못했습니다."); }
    finally { setBusy(false); }
  }, []);

  useEffect(() => { void start(); void loadLeaderboard(); }, [start, loadLeaderboard]);
  useEffect(() => {
    if (!run || feedback?.done) return;
    const timer = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(timer);
  }, [run, feedback?.done]);

  const submit = useCallback(async (chosen = choice) => {
    if (!run || chosen === null || busy || feedback) return;
    setBusy(true); setError("");
    try {
      const result = await post<Feedback>("/api/run/answer", { runId: run.runId, questionId: run.question.id, choice: chosen });
      setFeedback(result); setScore(result.score); setCorrectCount(result.correctCount);
      return result;
    } catch (e) { setError(e instanceof Error ? e.message : "답안을 제출하지 못했습니다."); }
    finally { setBusy(false); }
  }, [run, choice, busy, feedback]);

  useEffect(() => {
    type Context = { registerTool: (tool: { name: string; title: string; description: string; inputSchema: object; annotations: { readOnlyHint: boolean; untrustedContentHint: boolean }; execute: (input: unknown) => unknown }, options: { signal: AbortSignal }) => void | Promise<void> };
    const context = (document as Document & { modelContext?: Context }).modelContext;
    if (!context?.registerTool) return;
    const controller = new AbortController();
    const register = (tool: Parameters<Context["registerTool"]>[0]) => { void Promise.resolve(context.registerTool(tool, { signal: controller.signal })).catch(() => {}); };
    register({ name: "read_sequence_question", title: "현재 수열 문제 읽기", description: "화면에 표시된 수열과 선택지를 읽습니다.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true, untrustedContentHint: false }, execute: () => run ? { question: run.question, position: run.position + 1, total: run.total } : { status: "loading" } });
    register({ name: "start_sequence_round", title: "새 수열 도전 시작", description: "새로운 10문항 수열추리 도전을 시작합니다.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: false, untrustedContentHint: false }, execute: async () => { await start(); return { status: "started" }; } });
    register({ name: "answer_sequence_question", title: "수열 문제 답하기", description: "현재 문제의 선택지 번호(1부터 5)를 제출하고 해설을 표시합니다.", inputSchema: { type: "object", properties: { option: { type: "integer", minimum: 1, maximum: 5 } }, required: ["option"], additionalProperties: false }, annotations: { readOnlyHint: false, untrustedContentHint: false }, execute: async (input) => { const option = (input as { option?: number }).option; if (!Number.isInteger(option) || !option || option < 1 || option > 5) throw new Error("선택지 번호는 1~5입니다."); const result = await submit(option - 1); if (!result) throw new Error("현재 답안을 제출할 수 없습니다."); return { correct: result.correct, answer: result.answer, explanation: result.explanation, score: result.score, done: result.done }; } });
    return () => controller.abort();
  }, [run, start, submit]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (view !== "practice" || !run || feedback || (event.target instanceof HTMLInputElement)) return;
      if (/^[1-5]$/.test(event.key)) setChoice(Number(event.key) - 1);
      if (event.key === "Enter") void submit();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [view, run, feedback, submit]);

  function advance() {
    if (!run || !feedback?.nextQuestion) return;
    setRun({ ...run, question: feedback.nextQuestion, position: feedback.position });
    setFeedback(null); setChoice(null);
  }

  async function saveScore() {
    if (!run || busy) return;
    setBusy(true); setError("");
    try {
      await post("/api/run/finish", { runId: run.runId, nickname });
      setSaved(true); await loadLeaderboard(); setView("leaderboard");
    } catch (e) { setError(e instanceof Error ? e.message : "순위 등록에 실패했습니다."); }
    finally { setBusy(false); }
  }

  const roundDone = Boolean(feedback?.done);
  const currentNumber = (run?.position ?? 0) + 1;
  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");

  return <Tabs value={view} onValueChange={(value) => { setView(value); if (value === "leaderboard") void loadLeaderboard(); }} className="shell">
    <header className="topbar">
      <div className="brand"><span className="brandmark">∑</span><span>수열연구소</span></div>
      <TabsList variant="line" className="topnav"><TabsTrigger value="practice">문제 풀기</TabsTrigger><TabsTrigger value="leaderboard">리더보드</TabsTrigger></TabsList>
      <span className="topnote">수열추리 집중 훈련</span>
    </header>
    <TabsContent value="practice" className="workspace">
      <aside className="sidebar">
        <span className="eyebrow">TRAINING MODE</span><h1>어려운 수열만,<br/>계속.</h1>
        <p>서로 다른 규칙이 겹친 수열을 집중해서 풀어보세요.</p>
        <div className="mode">01　 실전 10문항</div>
        <div className="side-details"><strong>2,249</strong><span>창작 문제 저장</span><strong>6</strong><span>복합 규칙 유형</span></div>
        <div className="sidefoot">독립 제작 연습 문제 · SK 공식 서비스 아님</div>
      </aside>
      <section className="mainpanel" aria-live="polite">
        {!run ? <div className="loadcard"><span className="eyebrow">PRACTICE</span><h2>문제를 준비하고 있어요</h2><p>6가지 복합 규칙에서 10문항을 고릅니다.</p><button className="primary" onClick={() => void start()} disabled={busy}>다시 불러오기</button>{error && <p className="error">{error}</p>}</div> :
        roundDone ? <div className="finishcard"><span className="eyebrow">ROUND COMPLETE</span><h2>10문항 완료</h2><div className="result-score">{score.toLocaleString()}<small>점</small></div><p>{correctCount}/10 정답 · {feedback?.durationSeconds ?? seconds}초</p><div className={`feedback ${feedback?.correct ? "good" : "bad"}`}><div className="feedback-head"><strong>마지막 문제 정답: {feedback?.answer}</strong></div><p>{feedback?.explanation}</p></div><label htmlFor="nickname">리더보드에 남길 이름</label><div className="save-row"><input id="nickname" maxLength={16} value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="닉네임 2~16자" /><button className="primary" onClick={() => void saveScore()} disabled={busy || nickname.trim().length < 2}>{saved ? "등록 완료" : "기록 등록"}</button></div><button className="text-button" onClick={() => void start()}>새 도전 시작 ↗</button>{error && <p className="error">{error}</p>}</div> :
        <><div className="panel-head"><div><span className="eyebrow">PRACTICE / {String(currentNumber).padStart(2, "0")} OF 10</span><h2>다음에 올 수는?</h2></div><span className="difficulty">● 고난도</span></div>
        <div className="progress"><span style={{ width: `${currentNumber * 10}%` }} /></div>
        <div className="question" aria-label={`수열: ${run.question.terms.join(", ")}, 다음 수는?`}>{run.question.terms.map((n,i)=><span key={i}>{n}{i < run.question.terms.length-1 && <b>·</b>}</span>)}<em>?</em></div>
        <div className="question-meta"><span>수열의 규칙을 찾아 빈칸을 채우세요.</span><span>{mm}:{ss}</span></div>
        <div className="answers">{run.question.options.map((n,i)=><button key={i} className={choice===i ? "selected" : ""} onClick={() => setChoice(i)} disabled={Boolean(feedback) || busy} aria-pressed={choice===i}><small>0{i+1}</small><strong>{n}</strong></button>)}</div>
        {feedback && <div className={`feedback ${feedback.correct ? "good" : "bad"}`}><div className="feedback-head"><strong>{feedback.correct ? "정답입니다" : `정답은 ${feedback.answer}`}</strong><span>{feedback.correct ? `+${feedback.gained}점` : "0점"}</span></div><p>{feedback.explanation}</p></div>}
        <div className="actions"><span>{feedback ? `${correctCount}문항 정답 · ${score.toLocaleString()}점` : "숫자키 1–5로 선택할 수 있어요"}</span>{feedback ? <button className="primary" onClick={advance}>다음 문제 ↗</button> : <button className="primary" onClick={() => void submit()} disabled={choice===null || busy}>정답 확인 ↗</button>}</div>
        {error && <p className="error">{error}</p>}<Scratchpads /></>}
      </section>
      <aside className="rightpanel"><span className="eyebrow">CURRENT RUN</span><div className="stat"><strong>{String(run?.position ?? 0).padStart(2,"0")}</strong><span>푼 문제</span></div><div className="stat"><strong>{correctCount}</strong><span>정답</span></div><div className="stat"><strong>{score.toLocaleString()}</strong><span>점수</span></div><div className="rankbox"><span className="eyebrow">SCORING</span><p>정답 100점 + 문제당 최대 50점의 속도 점수. 10문항을 끝내면 순위에 등록할 수 있어요.</p></div></aside>
    </TabsContent>
    <TabsContent value="leaderboard" className="leaderboard-page"><div className="leaderboard-wrap"><div className="leader-head"><div><span className="eyebrow">LEADERBOARD</span><h1>10문항 리더보드</h1><p>정답 점수와 풀이 속도를 합산합니다.</p></div><button className="primary" onClick={() => void start()}>새 도전 ↗</button></div>{leaderboardError && <p className="error">{leaderboardError}</p>}<div className="leader-table"><div className="leader-row leader-label"><span>순위</span><span>닉네임</span><span>정답</span><span>시간</span><span>점수</span></div>{entries.length ? entries.map((entry,i)=><div className="leader-row" key={i}><strong>{String(i+1).padStart(2,"0")}</strong><strong>{entry.nickname}</strong><span>{entry.correct}/10</span><span>{Math.round(entry.seconds)}초</span><strong>{entry.score.toLocaleString()}</strong></div>) : <div className="leader-empty">아직 등록된 기록이 없어요. 첫 10문항을 풀어보세요.</div>}</div></div></TabsContent>
  </Tabs>;
}
