"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import bankMeta from "@/lib/bank-meta.json";

type Question = { id: string; family: string; terms: string[]; options: string[] };
type Entry = { nickname: string; correct: number; score: number; seconds: number };
type Feedback = { correct: boolean; answer: string; explanation: string; gained: number; score: number; correctCount: number; position: number; done: boolean; durationSeconds: number | null; nextQuestion: Question | null };
type Run = { runId: string; question: Question; position: number; total: number };
type Mode = "ten" | "twenty" | "instant";
type Review = { question: Question; choice: number; feedback: Feedback };
const API_BASE = typeof document === "undefined" ? "" : document.querySelector<HTMLMetaElement>('meta[name="api-base"]')?.content ?? "";
const formatDuration = (value: number) => {
  const seconds = Math.max(0, Math.round(value));
  return `${Math.floor(seconds / 60)}분 ${seconds % 60}초`;
};

function Scratchpads() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const [memo, setMemo] = useState("");
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const resize = () => {
      const snapshot = document.createElement("canvas");
      snapshot.width = canvas.width; snapshot.height = canvas.height;
      snapshot.getContext("2d")?.drawImage(canvas, 0, 0);
      const width = Math.max(1, Math.round(canvas.clientWidth * devicePixelRatio));
      const height = Math.max(1, Math.round(canvas.clientHeight * devicePixelRatio));
      if (canvas.width === width && canvas.height === height) return;
      canvas.width = width; canvas.height = height;
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, width, height);
      ctx.drawImage(snapshot, 0, 0);
      ctx.strokeStyle = "#163f35"; ctx.lineWidth = 2.5 * devicePixelRatio;
      ctx.lineCap = "round"; ctx.lineJoin = "round";
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    return () => observer.disconnect();
  }, []);
  function point(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return { x: (event.clientX - rect.left) * canvas.width / rect.width, y: (event.clientY - rect.top) * canvas.height / rect.height };
  }
  function down(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    canvas.setPointerCapture(event.pointerId); drawing.current = true;
    const p = point(event); ctx.beginPath(); ctx.moveTo(p.x, p.y);
  }
  function move(event: React.PointerEvent<HTMLCanvasElement>) {
    if (!drawing.current) return;
    const ctx = canvasRef.current?.getContext("2d"); if (!ctx) return;
    const p = point(event); ctx.lineTo(p.x, p.y); ctx.stroke();
  }
  function clearDrawing() {
    const canvas = canvasRef.current, ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
  }
  return <div className="scratchpads">
    <div className="scratch-card"><div className="scratch-head"><strong>그림판</strong><button onClick={clearDrawing}>지우기</button></div><canvas ref={canvasRef} onPointerDown={down} onPointerMove={move} onPointerUp={() => drawing.current = false} onPointerCancel={() => drawing.current = false} aria-label="마우스나 터치로 풀이를 그리는 그림판" /></div>
    <div className="scratch-card"><div className="scratch-head"><strong>메모장</strong><button onClick={() => setMemo("")}>비우기</button></div><Textarea aria-label="풀이 메모장" placeholder="생각한 규칙이나 계산을 적어보세요." value={memo} onChange={(event) => setMemo(event.target.value)} /></div>
  </div>;
}

async function post<T>(url: string, body?: object): Promise<T> {
  const response = await fetch(API_BASE + url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body ?? {}) });
  const data = await response.json() as { error?: string };
  if (!response.ok) throw new Error(data.error ?? "요청에 실패했습니다.");
  return data as T;
}

export default function Home() {
  const [view, setView] = useState("practice");
  const [screen, setScreen] = useState<"select" | "question" | "results">("select");
  const [mode, setMode] = useState<Mode>("ten");
  const [run, setRun] = useState<Run | null>(null);
  const [choice, setChoice] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [seconds, setSeconds] = useState(0);
  const [score, setScore] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [nickname, setNickname] = useState("");
  const [saved, setSaved] = useState(false);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [leaderboardError, setLeaderboardError] = useState("");
  const [leaderboardTotal, setLeaderboardTotal] = useState<10 | 20>(10);
  const [review, setReview] = useState<Review[]>([]);

  const loadLeaderboard = useCallback(async (total: 10 | 20) => {
    try {
      const response = await fetch(API_BASE + `/api/leaderboard?total=${total}`, { cache: "no-store" });
      const data = await response.json() as { error?: string; entries?: Entry[] };
      if (!response.ok) throw new Error(data.error);
      setEntries(data.entries ?? []);
      setLeaderboardError("");
    } catch { setLeaderboardError("순위를 불러오지 못했습니다."); }
  }, []);

  const start = useCallback(async (selectedMode: Mode) => {
    setBusy(true); setError(""); setChoice(null); setFeedback(null); setScore(0); setCorrectCount(0); setSaved(false); setSeconds(0); setReview([]);
    try {
      const next = await post<Run>("/api/run", { total: selectedMode === "twenty" ? 20 : 10 });
      setMode(selectedMode);
      setRun(next);
      setScreen("question");
      setView("practice");
    } catch (e) { setError(e instanceof Error ? e.message : "문제를 불러오지 못했습니다."); }
    finally { setBusy(false); }
  }, []);

  useEffect(() => { void loadLeaderboard(leaderboardTotal); }, [loadLeaderboard, leaderboardTotal]);
  useEffect(() => {
    if (!run || screen !== "question" || feedback?.done) return;
    const timer = window.setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => window.clearInterval(timer);
  }, [run, screen, feedback?.done]);

  const submit = useCallback(async () => {
    if (!run || choice === null || busy || feedback) return;
    setBusy(true); setError("");
    try {
      const result = await post<Feedback>("/api/run/answer", { runId: run.runId, questionId: run.question.id, choice });
      setScore(result.score); setCorrectCount(result.correctCount);
      setReview((previous) => [...previous, { question: run.question, choice, feedback: result }]);
      if (mode === "instant") setFeedback(result);
      else if (result.done) { setFeedback(result); setScreen("results"); }
      else if (result.nextQuestion) {
        setRun({ ...run, question: result.nextQuestion, position: result.position });
        setChoice(null); setFeedback(null);
      } else throw new Error("다음 문제를 불러오지 못했습니다.");
    } catch (e) { setError(e instanceof Error ? e.message : "답안을 제출하지 못했습니다."); }
    finally { setBusy(false); }
  }, [run, choice, busy, feedback, mode]);

  function advance() {
    if (!run || !feedback) return;
    if (feedback.done) { setScreen("results"); return; }
    if (!feedback.nextQuestion) return;
    setRun({ ...run, question: feedback.nextQuestion, position: feedback.position });
    setFeedback(null); setChoice(null);
  }

  async function saveScore() {
    if (!run || busy) return;
    setBusy(true); setError("");
    try {
      await post("/api/run/finish", { runId: run.runId, nickname });
      setSaved(true); setLeaderboardTotal(run.total === 20 ? 20 : 10); await loadLeaderboard(run.total === 20 ? 20 : 10); setView("leaderboard");
    } catch (e) { setError(e instanceof Error ? e.message : "순위 등록에 실패했습니다."); }
    finally { setBusy(false); }
  }

  const currentNumber = (run?.position ?? 0) + 1;
  const total = run?.total ?? (mode === "twenty" ? 20 : 10);

  return <Tabs value={view} onValueChange={(value) => { setView(value); if (value === "leaderboard") void loadLeaderboard(leaderboardTotal); }} className="shell">
    <header className="topbar">
      <div className="brand"><span className="brandmark">∑</span><span>수열연구소</span></div>
      <TabsList variant="line" className="topnav"><TabsTrigger value="practice">문제 풀기</TabsTrigger><TabsTrigger value="leaderboard">리더보드</TabsTrigger></TabsList>
      <span className="topnote">수열추리 집중 훈련</span>
    </header>
    <TabsContent value="practice" className="workspace">
      <aside className="sidebar">
        <span className="eyebrow">TRAINING MODE</span><h1>어려운 수열만,<br/>계속.</h1>
        <p>서로 다른 규칙이 겹친 수열을 집중해서 풀어보세요. 수열 길이도 문제마다 달라집니다.</p>
        <div className="mode">{screen === "select" ? "풀이 방식 선택" : `${total}문항 · ${mode === "instant" ? "즉시 해설" : "마지막 해설"}`}</div>
        <div className="side-details"><strong>{bankMeta.total.toLocaleString()}</strong><span>창작 문제 저장</span><strong>{bankMeta.familyCount}</strong><span>세부 규칙 유형</span></div>
        <div className="sidefoot">독립 제작 연습 문제 · SK 공식 서비스 아님</div>
      </aside>
      <section className="mainpanel" aria-live="polite">
        {screen === "select" ? <div className="mode-select"><span className="eyebrow">CHOOSE A MODE</span><h2>어떻게 풀어볼까요?</h2><p>번호를 마우스로 고르세요. 실전 모드는 다음 문제로 바로 넘어가고, 학습 모드는 답을 바로 확인해요.</p><div className="mode-cards"><button onClick={() => void start("ten")} disabled={busy}><small>01 · 실전</small><strong>10문항</strong><span>모두 푼 뒤 전체 해설 보기</span></button><button onClick={() => void start("twenty")} disabled={busy}><small>02 · 긴 실전</small><strong>20문항</strong><span>모두 푼 뒤 전체 해설 보기</span></button><button onClick={() => void start("instant")} disabled={busy}><small>03 · 학습</small><strong>한 문제씩</strong><span>10문항 · 제출 직후 해설 보기</span></button></div>{busy && <p>문제를 준비하고 있어요…</p>}{error && <p className="error">{error}</p>}</div> :
        screen === "results" && run ? <div className="results"><span className="eyebrow">ROUND COMPLETE</span><h2>{total}문항 완료</h2><div className="result-score">{score.toLocaleString()}<small>점</small></div><p>{correctCount}/{total} 정답 · 풀이 시간 {formatDuration(feedback?.durationSeconds ?? seconds)}</p><h3>전체 해설</h3><div className="review-list">{review.map((item, index) => <article className={`review-item ${item.feedback.correct ? "good" : "bad"}`} key={index}><div className="review-title"><strong>{String(index + 1).padStart(2, "0")}. {item.question.terms.join(" · ")} · ?</strong><span>{item.feedback.correct ? "정답" : "오답"}</span></div><p>{item.question.family} · 내 선택: {item.question.options[item.choice]}　 정답: {item.feedback.answer}</p><p>{item.feedback.explanation}</p></article>)}</div><label htmlFor="nickname">리더보드에 남길 이름</label><div className="save-row"><input id="nickname" maxLength={16} value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="닉네임 2~16자" disabled={saved} /><button className="primary" onClick={() => void saveScore()} disabled={busy || saved || nickname.trim().length < 2}>{saved ? "등록 완료" : "기록 등록"}</button></div><button className="text-button" onClick={() => { setScreen("select"); setRun(null); setFeedback(null); }}>다른 모드로 도전 ↗</button>{error && <p className="error">{error}</p>}</div> :
        run ? <><div className="panel-head"><div><span className="eyebrow">PRACTICE / {String(currentNumber).padStart(2, "0")} OF {total}</span><h2>다음에 올 수는?</h2></div><span className="difficulty">● 고난도</span></div>
        <div className="progress"><span style={{ width: `${currentNumber / total * 100}%` }} /></div>
        <div className="question" aria-label={`수열: ${run.question.terms.join(", ")}, 다음 수는?`}>{run.question.terms.map((n,i)=><span key={i}>{n}{i < run.question.terms.length-1 && <b>·</b>}</span>)}<em>?</em></div>
        <div className="question-meta"><span>수열의 규칙을 찾아 빈칸을 채우세요.</span><span>{formatDuration(seconds)}</span></div>
        <div className="answers">{run.question.options.map((n,i)=><button key={i} className={choice===i ? "selected" : ""} onClick={(event) => { if (event.detail > 0) setChoice(i); }} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") event.preventDefault(); }} disabled={Boolean(feedback) || busy} aria-pressed={choice===i}><small>0{i+1}</small><strong>{n}</strong></button>)}</div>
        {feedback && <div className={`feedback ${feedback.correct ? "good" : "bad"}`}><div className="feedback-head"><strong>{feedback.correct ? "정답입니다" : `정답은 ${feedback.answer}`}</strong><span>{feedback.correct ? `+${feedback.gained}점` : "0점"}</span></div><p>{feedback.explanation}</p></div>}
        <div className="actions"><span>{mode === "instant" && feedback ? `${feedback.position}/${total}문항 제출` : mode === "instant" ? "번호를 클릭한 뒤 정답 확인을 눌러주세요" : "번호를 클릭한 뒤 다음 문제로 넘어가세요"}</span>{mode === "instant" && feedback ? <button className="primary" onClick={advance}>{feedback.done ? "결과 및 전체 해설 ↗" : "다음 문제 ↗"}</button> : <button className="primary" onClick={(event) => { if (event.detail > 0) void submit(); }} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") event.preventDefault(); }} disabled={choice===null || busy}>{mode === "instant" ? "정답 확인 ↗" : currentNumber === total ? "결과 및 전체 해설 ↗" : "다음 문제 ↗"}</button>}</div>
        {error && <p className="error">{error}</p>}<Scratchpads key={`${run.runId}-${run.position}`} /></> : null}
      </section>
      <aside className="rightpanel"><span className="eyebrow">CURRENT RUN</span><div className="stat"><strong>{String(screen === "select" ? 0 : review.length).padStart(2,"0")}</strong><span>푼 문제</span></div><div className="stat"><strong>{screen === "results" ? correctCount : "—"}</strong><span>정답</span></div><div className="stat"><strong>{screen === "results" ? score.toLocaleString() : "—"}</strong><span>점수</span></div><div className="rankbox"><span className="eyebrow">SCORING</span><p>정답 100점 + 문제당 최대 50점의 속도 점수. 실전 모드의 정답과 점수는 마지막에 공개해요.</p></div></aside>
    </TabsContent>
    <TabsContent value="leaderboard" className="leaderboard-page"><div className="leaderboard-wrap"><div className="leader-head"><div><span className="eyebrow">LEADERBOARD</span><h1>{leaderboardTotal}문항 리더보드</h1><p>정답 점수와 풀이 속도를 합산합니다.</p></div><button className="primary" onClick={() => { setScreen("select"); setRun(null); setView("practice"); }}>새 도전 ↗</button></div><div className="leader-filters"><button className={leaderboardTotal === 10 ? "active" : ""} onClick={() => setLeaderboardTotal(10)}>10문항</button><button className={leaderboardTotal === 20 ? "active" : ""} onClick={() => setLeaderboardTotal(20)}>20문항</button></div>{leaderboardError && <p className="error">{leaderboardError}</p>}<div className="leader-table"><div className="leader-row leader-label"><span>순위</span><span>닉네임</span><span>정답</span><span>시간</span><span>점수</span></div>{entries.length ? entries.map((entry,i)=><div className="leader-row" key={i}><strong>{String(i+1).padStart(2,"0")}</strong><strong>{entry.nickname}</strong><span>{entry.correct}/{leaderboardTotal}</span><span>{formatDuration(entry.seconds)}</span><strong>{entry.score.toLocaleString()}</strong></div>) : <div className="leader-empty">아직 등록된 기록이 없어요. 첫 {leaderboardTotal}문항에 도전해 보세요.</div>}</div></div></TabsContent>
  </Tabs>;
}
