ALTER TABLE `daily_runs` ADD `elapsed_ms` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `daily_runs` ADD `active_since` integer;--> statement-breakpoint
ALTER TABLE `runs` ADD `elapsed_ms` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `runs` ADD `active_since` integer;