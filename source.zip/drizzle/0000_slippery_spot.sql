CREATE TABLE `runs` (
	`id` text PRIMARY KEY NOT NULL,
	`question_ids` text NOT NULL,
	`position` integer DEFAULT 0 NOT NULL,
	`correct` integer DEFAULT 0 NOT NULL,
	`score` integer DEFAULT 0 NOT NULL,
	`started_at` integer NOT NULL,
	`question_started_at` integer NOT NULL,
	`finished_at` integer,
	`nickname` text
);
--> statement-breakpoint
CREATE INDEX `idx_runs_score_finished` ON `runs` (`score`,`finished_at`);