CREATE TABLE `visitor_days` (
	`visitor_id` text NOT NULL,
	`day` text NOT NULL,
	PRIMARY KEY(`visitor_id`, `day`)
);
--> statement-breakpoint
CREATE INDEX `idx_visitor_days_day` ON `visitor_days` (`day`);--> statement-breakpoint
CREATE TABLE `visitors` (
	`id` text PRIMARY KEY NOT NULL,
	`first_seen` text NOT NULL
);
