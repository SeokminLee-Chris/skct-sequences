CREATE TABLE `daily_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`test_key` text NOT NULL,
	`question_ids` text NOT NULL,
	`choices_json` text DEFAULT '[]' NOT NULL,
	`position` integer DEFAULT 0 NOT NULL,
	`correct` integer DEFAULT 0 NOT NULL,
	`started_at` integer NOT NULL,
	`finished_at` integer,
	`nickname` text
);
--> statement-breakpoint
CREATE INDEX `idx_daily_runs_board` ON `daily_runs` (`test_key`,`correct`,`finished_at`);