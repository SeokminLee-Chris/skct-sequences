import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
const root = dirname(fileURLToPath(import.meta.url));
export default defineConfig({
  root: resolve(root, "gh-src"),
  base: "./",
  plugins: [react()],
  resolve: { alias: { "@": root } },
  publicDir: false,
  build: { outDir: resolve(root, "gh-pages-dist"), emptyOutDir: true },
});
