import bank from "./bank.json";
export type Question = typeof bank[number];
export const questions: Question[] = bank;
export const questionById = new Map(bank.map((q) => [q.id, q]));
export const publicQuestion = (q: Question) => ({ id: q.id, family: q.family, terms: q.terms, options: q.options });
export function pickQuestions(count: number) {
  const groups = [...new Set(bank.map((q) => q.family))];
  const selected: Question[] = [];
  for (let i = 0; i < count; i++) {
    const pool = bank.filter((q) => q.family === groups[i % groups.length] && !selected.some((picked) => picked.id === q.id));
    selected.push(pool[Math.floor(Math.random() * pool.length)]);
  }
  return selected.sort(() => Math.random() - 0.5);
}
