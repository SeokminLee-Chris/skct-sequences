import bank from "./bank.json";
export type Question = typeof bank[number];
export const questions: Question[] = bank;
export const questionById = new Map(bank.map((q) => [q.id, q]));
export const publicQuestion = (q: Question) => ({ id: q.id, family: q.family, terms: q.terms, options: q.options });
const groups = [...new Set(bank.map((q) => q.group))];
const byGroupAndFamily = new Map<string, Question[]>();
for (const q of bank) {
  const key = `${q.group}/${q.family}`;
  const pool = byGroupAndFamily.get(key) ?? [];
  pool.push(q);
  byGroupAndFamily.set(key, pool);
}
function shuffle<T>(items: T[]) {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}
export function pickQuestions(count: number) {
  if (count !== 10 && count !== 20) throw new Error("Unsupported round length");
  const chosenGroups = shuffle(groups).slice(0, 10);
  const selected: Question[] = [];
  const familyByGroup = new Map(chosenGroups.map((group) => [group, shuffle([...new Set(bank.filter((q) => q.group === group).map((q) => q.family))])]));
  for (let block = 0; block < count / 10; block++) {
    for (const group of chosenGroups) {
      const family = familyByGroup.get(group)?.[block];
      if (!family) throw new Error(`Not enough patterns in ${group}`);
      const pool = byGroupAndFamily.get(`${group}/${family}`);
      if (!pool?.length) throw new Error(`No questions in ${family}`);
      selected.push(pool[Math.floor(Math.random() * pool.length)]);
    }
  }
  return selected;
}
