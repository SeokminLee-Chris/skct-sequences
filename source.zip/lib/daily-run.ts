import { db } from "./store";
import { DAILY_LIMIT_MS, dailyReview } from "./daily";

export type DailyRunRow = { id: string; test_key: string; question_ids: string; choices_json: string; position: number; correct: number; started_at: number; elapsed_ms: number; active_since: number | null; finished_at: number | null; nickname: string | null };
export async function getDailyRun(id: string) {
  return db().prepare("SELECT id, test_key, question_ids, choices_json, position, correct, started_at, elapsed_ms, active_since, finished_at, nickname FROM daily_runs WHERE id = ?").bind(id).first<DailyRunRow>();
}
export function elapsedMs(run: DailyRunRow, now = Date.now()) {
  return run.elapsed_ms + (run.active_since === null ? 0 : Math.max(0, now - run.active_since));
}
export async function finishExpired(run: DailyRunRow, now = Date.now()) {
  if (elapsedMs(run, now) < DAILY_LIMIT_MS) return null;
  await db().prepare("UPDATE daily_runs SET finished_at = ?, elapsed_ms = ?, active_since = NULL WHERE id = ? AND finished_at IS NULL")
    .bind(now, DAILY_LIMIT_MS, run.id).run();
  const latest = await getDailyRun(run.id);
  if (!latest) throw new Error("Daily run vanished");
  const ids = JSON.parse(latest.question_ids) as string[];
  const choices = JSON.parse(latest.choices_json) as (number | null)[];
  return { timedOut: true, done: true, correctCount: latest.correct, score: latest.correct * 100, position: latest.position, total: 20, durationSeconds: DAILY_LIMIT_MS / 1000, review: dailyReview(ids, choices) };
}
