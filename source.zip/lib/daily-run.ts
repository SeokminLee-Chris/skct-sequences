import { db } from "./store";
import { DAILY_LIMIT_MS, dailyReview } from "./daily";

export type DailyRunRow = { id: string; test_key: string; question_ids: string; choices_json: string; position: number; correct: number; started_at: number; finished_at: number | null; nickname: string | null };
export async function getDailyRun(id: string) {
  return db().prepare("SELECT id, test_key, question_ids, choices_json, position, correct, started_at, finished_at, nickname FROM daily_runs WHERE id = ?").bind(id).first<DailyRunRow>();
}
export async function finishExpired(run: DailyRunRow, now = Date.now()) {
  const deadline = run.started_at + DAILY_LIMIT_MS;
  if (now < deadline) return null;
  await db().prepare("UPDATE daily_runs SET finished_at = ? WHERE id = ? AND finished_at IS NULL")
    .bind(deadline, run.id).run();
  const latest = await getDailyRun(run.id);
  if (!latest) throw new Error("Daily run vanished");
  const ids = JSON.parse(latest.question_ids) as string[];
  const choices = JSON.parse(latest.choices_json) as (number | null)[];
  return { timedOut: true, done: true, correctCount: latest.correct, score: latest.correct * 100, position: latest.position, total: 20, durationSeconds: DAILY_LIMIT_MS / 1000, review: dailyReview(ids, choices) };
}
