import bank from "./bank.json";
import { publicQuestion, questionById, type Question } from "./questions";

export const DAILY_LIMIT_MS = 15 * 60 * 1000;
export const DAILY_TEST_COUNT = 10;
const groups = [...new Set(bank.map((q) => q.group))];
const families = new Map(groups.map((group) => [group, [...new Set(bank.filter((q) => q.group === group).map((q) => q.family))]]));
const pools = new Map<string, Question[]>();
for (const q of bank) {
  const key = `${q.group}/${q.family}`;
  const list = pools.get(key) ?? [];
  list.push(q);
  pools.set(key, list);
}

export function todayInSeoul(now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Seoul", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(now);
  const value = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${value.year}-${value.month}-${value.day}`;
}

function randomFor(key: string) {
  let seed = 2166136261;
  for (let i = 0; i < key.length; i++) seed = Math.imul(seed ^ key.charCodeAt(i), 16777619) >>> 0;
  return () => {
    seed = (seed + 0x6d2b79f5) >>> 0;
    let x = Math.imul(seed ^ seed >>> 15, 1 | seed);
    x ^= x + Math.imul(x ^ x >>> 7, 61 | x);
    return ((x ^ x >>> 14) >>> 0) / 4294967296;
  };
}

function shuffled<T>(items: T[], random: () => number) {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

const cache = new Map<string, Question[][]>();
export function dailyTests(date: string) {
  const cached = cache.get(date);
  if (cached) return cached;
  const used = new Set<string>();
  const tests: Question[][] = [];
  for (let test = 1; test <= DAILY_TEST_COUNT; test++) {
    const random = randomFor(`${date}/test-${test}`);
    const chosenGroups = shuffled(groups, random).slice(0, 10);
    const chosenFamilies = new Map(chosenGroups.map((group) => [group, shuffled(families.get(group)!, random)]));
    const questions: Question[] = [];
    for (let block = 0; block < 2; block++) {
      for (const group of chosenGroups) {
        const family = chosenFamilies.get(group)![block];
        const available = shuffled(pools.get(`${group}/${family}`)!, random).find((q) => !used.has(q.id));
        if (!available) throw new Error(`Daily question pool exhausted: ${group}/${family}`);
        used.add(available.id);
        questions.push(available);
      }
    }
    tests.push(questions);
  }
  cache.clear();
  cache.set(date, tests);
  return tests;
}

export function dailyKey(date: string, test: number) { return `${date}/test-${test}`; }
export function dailyReview(ids: string[], choices: (number | null)[]) {
  return ids.map((id, i) => {
    const q = questionById.get(id);
    if (!q) throw new Error(`Missing question ${id}`);
    const choice = choices[i] ?? null;
    return { question: publicQuestion(q), choice, feedback: { correct: choice !== null && q.options[choice] === q.answer, answer: q.answer, explanation: q.explanation, gained: choice !== null && q.options[choice] === q.answer ? 100 : 0 } };
  });
}
