import { env } from "cloudflare:workers";
const corsHeaders = {
  "Access-Control-Allow-Origin": "https://seokminlee-chris.github.io",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};
export function corsJson(data: unknown, init?: ResponseInit) {
  const response = Response.json(data, init);
  for (const [key, value] of Object.entries(corsHeaders)) response.headers.set(key, value);
  return response;
}
export function preflight() { return new Response(null, { status: 204, headers: corsHeaders }); }
export function db() {
  if (!env.DB) throw new Error("D1 database is unavailable");
  return env.DB;
}
export function errorResponse(error: unknown) {
  console.error(error);
  return corsJson({ error: "기록을 불러오지 못했습니다. 잠시 후 다시 시도해 주세요." }, { status: 500 });
}
